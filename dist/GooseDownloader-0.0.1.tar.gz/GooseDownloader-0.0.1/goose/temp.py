from goose.main import run as goose_run


def main():
    goose_run()
